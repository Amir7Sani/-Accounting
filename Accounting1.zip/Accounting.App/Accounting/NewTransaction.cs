﻿using Accounting.DataLayer.Context;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ValidationComponents;

namespace Accounting.App
{
    public partial class NewTransaction : Form
    {
        UnitOfWork db;
        public int AccountID = 0;
        public NewTransaction()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            dgvCustomers.AutoGenerateColumns = false;
            dgvCustomers.DataSource = db.CustomerRepository.GetNameCustomers(txtFilter.Text);

        }

        private void NewTransaction_Load(object sender, EventArgs e)
        {
            db = new UnitOfWork();
            dgvCustomers.AutoGenerateColumns = false;
            dgvCustomers.DataSource = db.CustomerRepository.GetNameCustomers();
            if (AccountID != 0)
            {
                var account = db.AccountingRepository.GetById(AccountID);
                txtAmount.Text= account.Amount.ToString();
                txtDetails.Text=account.Description.ToString();
                txtName.Text=db.CustomerRepository.GetCustomerNameById(AccountID);
                if (account.TypeID == 1)
                {
                    rbRecieve.Checked= true;
                }
                else
                {
                    rbPay.Checked= true;
                }
                this.Text = "Edit Transaction";
                btnSave.Text = "Edit";
                db.Dispose();
            }

        }

        private void dgvCustomers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dgvCustomers_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtName.Text = dgvCustomers.CurrentRow.Cells[0].Value.ToString();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            db = new UnitOfWork();
            if (BaseValidator.IsFormValid(this.components))
            {
                {
                    if(rbPay.Checked||rbRecieve.Checked)
                    {
                        DataLayer.Accounting accounting = new DataLayer.Accounting()
                        {
                            Amount = int.Parse(txtAmount.Value.ToString()),
                            CustomerID = db.CustomerRepository.GetCustomerIdByName(txtName.Text),
                            TypeID = (rbRecieve.Checked) ? 1 : 2,
                            DateTime= DateTime.Now,
                            Description=txtDetails.Text
                        };
                        if (AccountID == 0)
                        {
                            db.AccountingRepository.Insert(accounting);
                        }
                        else
                        {
                            accounting.ID= AccountID;
                            db.AccountingRepository.Update(accounting);
                        }

                        db.Save();
                        db.Dispose();
                        DialogResult= DialogResult.OK;
                    }
                    else
                    {
                        MessageBox.Show("Please Select the Kind of Transaction!");
                    }
                }
            }

        }
    }
}

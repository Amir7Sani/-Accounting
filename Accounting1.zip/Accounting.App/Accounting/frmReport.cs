﻿using Accounting.DataLayer.Context;
using Accounting.ViewModels.Customer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Accounting.App
{
    public partial class frmReport : Form
    {
        public int TypeID = 0;
        public frmReport()
        {
            InitializeComponent();
        }

        private void frmReport_Load(object sender, EventArgs e)
        {
            using (UnitOfWork db = new UnitOfWork())
            {
               

                
                List<ListCustomerViewModel> list = new List<ListCustomerViewModel>();
                list.Add(new ListCustomerViewModel()
                {
                    CustomerID=0,
                    FullName="Please Select"
                });
                list.AddRange(db.CustomerRepository.GetNameCustomers());
                cbCustomer.DataSource = list;
                cbCustomer.DisplayMember= "FullName";
                cbCustomer.ValueMember= "CustomerID";


            }
            if (TypeID == 1)
            {
                this.Text = "Recieves Report";
            }
            else
            {
                this.Text = "Pays Report";
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void maskedTextBox2_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btnFilter_Click(object sender, EventArgs e)
        {
            Filter();
        }

        void Filter()
        {using(UnitOfWork db= new UnitOfWork())
            {
                DateTime? startDate;
                DateTime? endDate;
                List<DataLayer.Accounting> result= new List<DataLayer.Accounting>();
                int customerId = int.Parse(cbCustomer.SelectedValue.ToString());
                if ((int)cbCustomer.SelectedValue!=0)
                {
                    result.AddRange(db.AccountingRepository.Get(a => a.TypeID == TypeID && a.CustomerID ==customerId));
                }
                else
                {
                    result.AddRange(db.AccountingRepository.Get(a => a.TypeID == TypeID));
                }

                if (txtFromDate.Text != "  /  /")
                {
                    startDate = Convert.ToDateTime(txtFromDate.Text);
                    result = result.Where(r => r.DateTime >= startDate.Value).ToList();
                }
                if (txtToDate.Text != "  /  /")
                {
                    endDate = Convert.ToDateTime(txtToDate.Text);
                    result = result.Where(r => r.DateTime <= endDate.Value).ToList();

                }

                //dgReport.AutoGenerateColumns=false;
                //dgReport.DataSource= result;
                dgReport.Rows.Clear();
                foreach(var accounting in result)
                {
                    string customerName=db.CustomerRepository.GetCustomerNameById(accounting.CustomerID);
                    dgReport.Rows.Add(accounting.ID,customerName,accounting.Amount,accounting.Description,accounting.DateTime);
                }

        }
        }

        private void dgReport_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            Filter();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgReport.CurrentRow != null)
            {
                int id = int.Parse(dgReport.CurrentRow.Cells[0].Value.ToString());
                if(MessageBox.Show("Are you sure?", "Warning", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    using (UnitOfWork db=new UnitOfWork() )
                    {
                        db.AccountingRepository.Delete(id);
                        db.Save();
                        Filter();
                    }

                }
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dgReport.CurrentRow != null)
            {
                int id = int.Parse(dgReport.CurrentRow.Cells[0].Value.ToString());
                NewTransaction frmNew=  new NewTransaction();
                frmNew.AccountID= id;
                if(frmNew.ShowDialog() == DialogResult.OK) {
                    Filter();
                }
                }
        }

        private void cbCustomer_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
